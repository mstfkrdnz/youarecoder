"""Routes package initialization."""
