"""
Workspace routes (create, delete, manage).
"""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, current_app
from flask_login import login_required, current_user
from app import db
from app.models import Workspace
from app.services.workspace_provisioner import WorkspaceProvisioner, WorkspaceProvisionerError

bp = Blueprint('workspace', __name__, url_prefix='/workspace')


@bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """Create new workspace route with full provisioning."""
    if request.method == 'POST':
        name = request.form.get('name')

        # Check if company can create more workspaces
        if not current_user.company.can_create_workspace():
            flash('Workspace limit reached for your plan', 'error')
            return redirect(url_for('main.dashboard'))

        # Initialize provisioner
        provisioner = WorkspaceProvisioner()

        try:
            # Allocate port
            port = provisioner.allocate_port()

            # Generate secure password for code-server
            code_server_password = provisioner.generate_password()

            # Create workspace record
            workspace = Workspace(
                name=name,
                subdomain=f"{name}.{current_user.company.subdomain}",
                linux_username=f"{current_user.company.subdomain}_{name}",
                port=port,
                code_server_password=code_server_password,
                company_id=current_user.company.id,
                owner_id=current_user.id,
                status='pending',
                disk_quota_gb=current_user.company.plan == 'starter' and 10 or
                             (current_user.company.plan == 'team' and 50 or 250)
            )
            db.session.add(workspace)
            db.session.commit()

            # Provision workspace (Linux user, code-server, systemd service)
            result = provisioner.provision_workspace(workspace)

            if result['success']:
                flash(f'Workspace "{name}" created and provisioned successfully!', 'success')
                current_app.logger.info(f"Workspace created: {workspace.id} on port {port}")
            else:
                flash(f'Workspace created but provisioning incomplete', 'warning')

        except WorkspaceProvisionerError as e:
            current_app.logger.error(f"Workspace provisioning error: {str(e)}")
            flash(f'Error creating workspace: {str(e)}', 'error')
            return redirect(url_for('main.dashboard'))

        return redirect(url_for('main.dashboard'))

    return render_template('workspace/create.html')


@bp.route('/<int:workspace_id>/delete', methods=['POST'])
@login_required
def delete(workspace_id):
    """Delete workspace route with full deprovisioning."""
    workspace = Workspace.query.get_or_404(workspace_id)

    # Check ownership
    if workspace.owner_id != current_user.id and not current_user.is_admin():
        flash('Permission denied', 'error')
        return redirect(url_for('main.dashboard'))

    # Initialize provisioner
    provisioner = WorkspaceProvisioner()

    try:
        # Deprovision workspace (stop service, remove user, cleanup)
        result = provisioner.deprovision_workspace(workspace)

        if result['success']:
            flash(f'Workspace "{workspace.name}" deleted successfully', 'success')
            current_app.logger.info(f"Workspace deprovisioned: {workspace_id}")
        else:
            flash(f'Workspace deletion incomplete', 'warning')

    except WorkspaceProvisionerError as e:
        current_app.logger.error(f"Workspace deprovisioning error: {str(e)}")
        flash(f'Error deleting workspace: {str(e)}', 'error')

    return redirect(url_for('main.dashboard'))


@bp.route('/<int:workspace_id>')
@login_required
def view(workspace_id):
    """View workspace details route."""
    workspace = Workspace.query.get_or_404(workspace_id)

    # Check access
    if workspace.company_id != current_user.company_id:
        flash('Permission denied', 'error')
        return redirect(url_for('main.dashboard'))

    return render_template('workspace/view.html', workspace=workspace)
